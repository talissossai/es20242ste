#include<stdio.h>

int main(){
	
	float valor;
	
	printf("Digite o valor da compra: ");
	scanf("%f", &valor);
	
	if(valor <= 100){
		printf("Nao tem desconto");
	}else if (valor > 100 && valor <= 500){
	printf("O desconto eh de 10% e o valor a pagar eh: %f", valor + (valor * (10/100)));	
   }else{
   	printf("O desconto eh 20% e o valor a pagar eh: %f", valor + (valor * (20/200)));
   
   }

return 0;
}
