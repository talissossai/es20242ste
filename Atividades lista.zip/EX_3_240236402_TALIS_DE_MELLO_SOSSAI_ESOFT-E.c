#include<stdio.h>

int main(){
	
	float salario;
	int avaliacao, A, B, C;
	
	printf("Digite seu salario: ");
	scanf("%f", &salario);
	printf("Digite seu nivel da avaliacao: ");
	scanf("%d", &avaliacao);
	
	if(avaliacao == A){
		printf("O seu bonus eh de 15 porcento e seu novo salario eh: %.2f", salario + (salario * 0.15));
	}else if(avaliacao == B){
		printf("O seu bonus eh de 10 porcento e seu novo salario eh: %.2f", salario + (salario * 0.10));
	}else if(avaliacao == C){
		printf("O seu bonus eh de 5 porcento e seu novo salario eh: %.2f", salario + (salario * 0.05));	
	}else{
		printf("Nao ha bonus");
	}
	return 0;
	}
