#include<stdio.h>

int main(){
	
	int n1, n2;
	
	printf("Digite 2 numeros: ");
	scanf("%d%d", &n1, &n2);
	
	if(n1 == n2){
		printf("O numero eh um quadrado perfeito");
	}else{
		printf("O numero nao eh um quadrado perfeito");
	
}
return 0;
	}
